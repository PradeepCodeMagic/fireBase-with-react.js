// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
import { getAuth } from 'firebase/auth'
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyCcpOgdPLCjIsJASIV1zAsW0PCAB05ny04",
  authDomain: "pradeepform-c6b07.firebaseapp.com",
  databaseURL: "https://pradeepform-c6b07-default-rtdb.firebaseio.com",
  projectId: "pradeepform-c6b07",
  storageBucket: "pradeepform-c6b07.appspot.com",
  messagingSenderId: "474949065142",
  appId: "1:474949065142:web:ecdb7dc28d3a2c32ea4917",
  measurementId: "G-R4SFG7TK4E"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const database = getAuth(app)