import logo from './logo.svg';
import './App.css';
import { useNavigate } from 'react-router-dom';
import { get, getDatabase, ref, set } from "firebase/database";
import { v4 as randomId } from 'uuid'; //for make unic id and npm i uuid
import { useEffect, useState } from 'react';

function App() {

  const navigate = useNavigate();
  let SignOut = () => {
    localStorage.clear()
    navigate("/")

  }

  // post
  let HandleData = (e) => {
    e.preventDefault()
    var myValue = {
      name: e.target.name.value,
      mobile: e.target.mobile.value,
      email: e.target.email.value,
      password: e.target.password.value,

    }
    const uid = randomId()
    // console.log(uid) for randoum id genrate

    const db = getDatabase();
    set(ref(db, 'userInfo/' + uid), myValue)
    e.target.reset()
    displayData() //page refresh krne ki jrurt nhi rhegi
  }

  // display data
  let [showdata,setshowdata]=useState([])
  
  let displayData = () => {
    const dbRef = ref(getDatabase() ,"userInfo");
    get(dbRef)
    .then((snapshot) => {
      if (snapshot.exists()) {
        var fianalData=Object.entries(snapshot.val()).map(([id,data])=>{
          return(id,data)
        })
        setshowdata(fianalData)
      } else {
        console.log("No data available");
      }
    }).catch((error) => {
      console.error(error);
    });
    
  }

  useEffect(()=>{
    displayData()
    
  },[])
  return (
    <div className="App">

      <button onClick={SignOut}>Sign Out</button>

      {/* form */}

      <div className='container bg-secondary'>
        <form onSubmit={HandleData}>
          <div className="mb-3">
            <label for="exampleInputEmail1" className="form-label">Name</label>
            <input type="text" className="form-control" name='name' />

          </div>
          <div className="mb-3">
            <label for="exampleInputEmail1" className="form-label">Mobile</label>
            <input type="Number" className="form-control" name='mobile' />

          </div>
          <div className="mb-3">
            <label for="exampleInputEmail1" className="form-label">Email </label>
            <input type="email" className="form-control" name='email' />

          </div>
          <div className="mb-3">
            <label for="exampleInputPassword1" className="form-label">Password</label>
            <input type="text" className="form-control" name='password' />
          </div>

          <button type="submit" className="btn btn-primary">Submit</button>
        </form>
      </div>

      {/* table */}

   

      <div className='my-4'>
        <table className="table">
          <thead>
            <tr>
              <th scope="col">Sr.</th>
              <th scope="col">Name</th>
              <th scope="col">Email</th>
              <th scope="col">Password</th>
              {/* <th scope="col">EditData</th>
              <th scope="col">DeleteData</th> */}
            </tr>
          </thead>
          <tbody>

            {showdata.length>=1
            ?
            showdata.map((v,i)=>{
              return(
                <tr key={i}>
                <th scope="row">{i+1}</th>
                <td>{v.name}</td>
                <td>{v.email}</td>
                <td>{v.password}</td>
                {/* <td> Edit </td>
                <td>Delete </td> */}
              </tr>
              )
            })
            :
            "No data Found"
          }
           

          </tbody>
        </table>
      </div>
    </div>
  );
}

export default App;
