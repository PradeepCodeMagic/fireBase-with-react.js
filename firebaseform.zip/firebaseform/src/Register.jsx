import React, { useState } from 'react'
import { database } from "./Firebase.confic"
import { createUserWithEmailAndPassword, getAuth } from "firebase/auth"
import { useNavigate } from 'react-router-dom';
//createUserWithEmailAndPassword ye firebase ka bna bnaya h
export default function Register() {
  let [msg,setmsg]=useState("")
  const auth = getAuth(); //ye connection h
  const navigate = useNavigate();

  
    let handelData=(e)=>{
      e.preventDefault()
      
      
        
        var email=e.target.email.value
       var  password=e.target.password.value
      
      // console.log(registerData)
      if( email!="" && password!=""){
        createUserWithEmailAndPassword(auth,email,password)
      .then((ress) => {
        // Signed up 
        console.log(ress.user)
        setmsg("registration successfully")
        
      })
      .catch((error) => {
        // seterror(error.message)
        setmsg("email already used")
        
      });
      
      }
      else{
        setmsg("Please Fill All Inputs")
      }
      e.target.reset()

      navigate("/")
      
    }
  

  return (
    <div>
      <section className="h-100" style={{ backgroundColor: "#ccc" }}>
        <div className="container h-100">
          <div className="row d-flex justify-content-center align-items-center h-100">
            <div className="col-lg-12 col-xl-11">
              <div className="card text-black" style={{ borderRadius: "25px" }}>
                <div className="card-body p-md-5">
                  <div className="row justify-content-center">
                    <div className="col-md-10 col-lg-6 col-xl-5 order-2 order-lg-1">

                      <p className="text-center h1 fw-bold mb-5 mx-1 mx-md-4 mt-4">Sign up</p>
                      <h4 className='bg-danger '> {msg} </h4>
                      <form className="mx-1 mx-md-4" onSubmit={handelData}>

                        <div className="d-flex flex-row align-items-center mb-4">

                          <div className="form-outline flex-fill mb-0">
                            <input type="text" id="form3Example1c" className="form-control" />
                            <label className="form-label" for="form3Example1c">Your Name</label>
                          </div>
                        </div>

                        <div className="d-flex flex-row align-items-center mb-4">

                          <div className="form-outline flex-fill mb-0">
                            <input type="email" id="form3Example3c" className="form-control" name='email' />
                            <label className="form-label" for="form3Example3c">Your Email</label>
                          </div>
                        </div>

                        <div className="d-flex flex-row align-items-center mb-4">

                          <div className="form-outline flex-fill mb-0">
                            <input type="password" id="form3Example4c" className="form-control" name='password' />
                            <label className="form-label" for="form3Example4c">Password</label>
                          </div>
                        </div>





                        <div className="d-flex justify-content-center mx-4 mb-3 mb-lg-4">
                          <button className="btn btn-primary btn-lg">Register</button>
                        </div>

                      </form>

                    </div>
                    <div className="col-md-10 col-lg-6 col-xl-7 d-flex align-items-center order-1 order-lg-2">

                      <img src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-registration/draw1.webp"
                        className="img-fluid" alt="Sample image" />

                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
