import React, { useState } from 'react'
import "./Phonelogin.css"


export default function Phonelogin() {
    // let [phoneN,setphoneN]=useState([])
    // let [oto,setotp]=useState("")
    // let [cmfrmOtp,setcmfrmOtp]=useState("")

  

     var handleInput=(e)=>{
        var Mymobile=e.target.mobile.value;
        console.log(Mymobile)
    }
  return (
    <div class="container new-login-area">
    <div id='sign-in' class='login-setup-section'>
        <h3 class="request-otp-header">Please verify your mobile number</h3>
        <div class="form-group login-label">
            <label for="inputnumber">mobile number</label>
            <input type="number" class="form-control input-edit" placeholder='Enter mobile number' id="number" onChange={this.handleInput} name='mobile'/>
        </div>
        <button type="button" class="btn btn-default btn-lg btn-block request-otp" id='request-otp'>Get OTP</button>
    </div>
    <div id='verify-otp' class="login-setup-section">
        <i class="fa fa-chevron-left" aria-hidden="true"></i>
        <h3 class="request-otp-header">Verify OTP</h3>
        <div class="form-group login-label">
            <label for="inputnumber">One Time Password</label>
            <input type="number" class="form-control input-edit" placeholder='Enter OTP' id="number" onChange={this.handleInput} name='otp'/>
            <label class="pull-right resend-otp">Resend otp</label>
        </div>
        <button type="button" class="btn btn-default btn-lg btn-block request-otp ">Verify</button>
    </div>
</div>
  )
}
