import React, { useState } from 'react'
import "./Login.css"
import {database} from "./Firebase.confic"
import { getAuth, signInWithEmailAndPassword,GoogleAuthProvider, signInWithPopup } from "firebase/auth"
import { Link, useNavigate } from 'react-router-dom';

export default function Login() {
  let [msg,setmsg]=useState("")
  let [localData,setlocalData]=useState([])
  const auth = getAuth(); //ye connection h
  const navigate = useNavigate();

  
    let handelData=(e)=>{
      e.preventDefault()
      
      
        
        var email=e.target.email.value
       var  password=e.target.password.value
      
       signInWithEmailAndPassword(auth,email,password)
       .then((ress) => {
         // Signed up 
         const user=ress.user;
         localStorage.setItem("userData",JSON.stringify(user))
       let usermail = JSON.parse(localStorage.getItem("userData")) || [];
       setlocalData(usermail.email);
         
       })
       .catch((error) => {
         
       });

       if(localData!=""){
           navigate("/homepage")
       }
       else{
        navigate("/")
       }
      
      
    }
    // google
    const provider = new GoogleAuthProvider();
    let siginGoogle=()=>{
      signInWithPopup(auth, provider)
      .then((result) => {
        // This gives you a Google Access Token. You can use it to access the Google API.
        const credential = GoogleAuthProvider.credentialFromResult(result);
        const token = credential.accessToken;
        // The signed-in user info.
        
        // IdP data available using getAdditionalUserInfo(result)
        // ...
        navigate("/homepage")
      }).catch((error) => {
        // Handle Errors here.
        const errorCode = error.code;
        const errorMessage = error.message;
        // The email of the user's account used.
        const email = error.customData.email;
        // The AuthCredential type that was used.
        const credential = GoogleAuthProvider.credentialFromError(error);
        // ...
      });
      
    }
    
    
    
  return (
    <div>
      <section class="vh-100 gradient-custom">
  <div class="container py-5 h-100">
    <div class="row d-flex justify-content-center align-items-center h-100">
      <div class="col-12 col-md-8 col-lg-6 col-xl-5">
        <div class="card bg-dark text-white">
          <div class="card-body p-5 text-center">

            <div class="mb-md-0 mt-md-0 ">
            <h4 className='bg-danger'> {msg} </h4>
              <h2 class="fw-bold mb-0 text-uppercase p-0 m-0">Login</h2>
              <p class="text-white-50 mb-3">Please enter your login and password!</p>
            <form onSubmit={handelData}>
              
            <div class="form-outline form-white mb-4">
                <input type="email" id="typeEmailX" class="form-control form-control-lg" name='email' />
                <label class="form-label" for="typeEmailX">Email</label>
              </div>

              <div class="form-outline form-white mb-4">
                <input type="password" id="typePasswordX" class="form-control form-control-lg" name='password'/>
                <label class="form-label" for="typePasswordX">Password</label>
              </div>

              {/* <p class="small mb-5 pb-lg-2"><a class="text-white-50" href="#!">Forgot password?</a></p> */}

              <button class="btn btn-outline-light btn-lg px-5" type="submit">Login</button> 
              <br/>
            </form>

            <button class="btn btn-outline-light btn-lg px-5 mt-3" type="submit" onClick={siginGoogle}>Login with google</button>

           

              <div>
              <p class="mb-0">Don't have an account? <a href="#!" class="text-white-50 fw-bold"><Link to={"/register"}> Sign Up</Link></a>
              </p>
            </div>
            </div>


          </div>
        </div>
      </div>
    </div>
  </div>
</section>
    </div>
  )
}
