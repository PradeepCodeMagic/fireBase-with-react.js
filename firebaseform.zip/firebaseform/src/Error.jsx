import React from 'react'

export default function Error() {
  return (
    <div className='container-fluid h-100vh'>
      <img src='https://assets.materialup.com/uploads/22233eec-511f-4875-bef4-01e9925424ad/preview.gif' className='img-fluid  w-100'/>
    </div>
  )
}
